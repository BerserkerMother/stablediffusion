from dataclasses import dataclass


@dataclass
class InferModelConfig:
    model_path = "model.quantize.onnx"


@dataclass
class FlaskConfig:
    host = "127.0.0.1"
    port = "1234"
    model_config = InferModelConfig()
